package br.ulbra.appbuguer;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edtLogin_main,edtPass_main;
    Button btnLogin_main;
        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edtLogin_main = findViewById(R.id.edtLogin_main);
        edtPass_main = findViewById(R.id.edtPass_main);
        btnLogin_main = findViewById(R.id.btnLogin_main);
        btnLogin_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                setContentView(R.layout.catalogo);

                }catch (Exception e){}
            }

        });


        };


    }
