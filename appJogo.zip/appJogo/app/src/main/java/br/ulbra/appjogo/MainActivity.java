package br.ulbra.appjogo;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Random;
public class MainActivity extends AppCompatActivity {
    Button btnp,btnPe,btnT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        }
    public void selecionadoPedra(View view) {
        this.opcaoSelecionado("pedra");
    }
    public void selecionadoPapel(View view) {
        this.opcaoSelecionado("papel");
    }
    public void selecionadoTesoura(View view) {
        this.opcaoSelecionado("tesoura");
    }
    public void opcaoSelecionado(String opcaoSelecionada) {
        TextView txtR = findViewById(R.id.txtR);
        ImageView imgJogada = findViewById(R.id.imgJogada);
        String opcoes[] = {"pedra", "papel", "tesoura"};
        String opcaoApp = opcoes[new Random().nextInt(3)];
        switch (opcaoApp) {
            case "pedra":
                imgJogada.setImageResource(R.drawable.pedra);
                break;
            case "papel":
                imgJogada.setImageResource(R.drawable.papel);
                break;
            case "tesoura":
                imgJogada.setImageResource(R.drawable.tesoura);
                break;
        }
        if ((opcaoApp.equals("tesoura") && opcaoSelecionada.equals("papel")) ||
        (opcaoApp.equals("papel")&& opcaoSelecionada.equals("pedra")) ||
        (opcaoApp.equals("pedra") && opcaoSelecionada.equals("tesoura")))
        {
            txtR.setText("Resultado: Você PERDEU... :");

        } else if ((opcaoSelecionada.equals("tesoura") && opcaoApp.equals("papel")) ||
        (opcaoSelecionada.equals("papel") && opcaoApp.equals("pedra")) ||
        (opcaoSelecionada.equals("pedra") && opcaoApp.equals("tesoura"))) {
            txtR.setText("Resultado: Você GANHOU... ");
        } else {
            txtR.setText("Resultado: Vocês EMPATARAM... ");
        }





    }
    public void opcoesJ(View view){
       ImageView imgT,imgP,imgPe;
       this.selecionadoTesoura(View view);

    }
}