package br.ulbra.appcalc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edtN1,edtN2;
    Button btnS,btnD,btnM,btnDiv;
    TextView txtT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edtN1 = findViewById(R.id.edtN1);
        edtN2 = findViewById(R.id.edtN2);
        txtT = findViewById(R.id.txtT);
        btnS = findViewById(R.id.btnS);
        btnD = findViewById(R.id.btnD);
        btnM = findViewById(R.id.btnM);
        btnDiv = findViewById(R.id.btnDiv);
        btnS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1,n2,result;
                n1 = Double.parseDouble(edtN1.getText().toString());
                n2 = Double.parseDouble(edtN2.getText().toString());
                result = n1+n2;
                txtT.setText("O resultado é: "+result);
            }
        });
        btnD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1,n2,result;
                n1 = Double.parseDouble(edtN1.getText().toString());
                n2 = Double.parseDouble(edtN2.getText().toString());
                result = n1-n2;
                txtT.setText("O resultado é: "+result);
            }
        });
        btnM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1,n2,result;
                n1 = Double.parseDouble(edtN1.getText().toString());
                n2 = Double.parseDouble(edtN2.getText().toString());
                result = n1*n2;
                txtT.setText("O resultado é: "+result);
            }
        });
        btnDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1,n2,result;
                n1 = Double.parseDouble(edtN1.getText().toString());
                n2 = Double.parseDouble(edtN2.getText().toString());
                result = n1/n2;
                txtT.setText("O resultado é: "+result);
            }
        });
        };
    }
