package br.ulbra.visualizadordeimagens;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    ImageView imgfoto1;
    Button btnfoto1, btnfoto2;
    TextView txtinformacao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        imgfoto1 = (ImageView) findViewById(R.id.imgfoto1);
        btnfoto1 = (Button) findViewById(R.id.btnfoto1);
        btnfoto2 = (Button) findViewById(R.id.btnfoto2);
        txtinformacao = (TextView) findViewById(R.id.txtinformacao);
        btnfoto1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgfoto1.setImageResource(R.drawable.gato);
                txtinformacao.setText("foto 1");
            }
        });
        btnfoto2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgfoto1.setImageResource(R.drawable.capivara);
                txtinformacao.setText("foto 2");
            }
        });
    };
    }
