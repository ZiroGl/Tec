package br.ulbra.appfuel;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edtNV,edtNP,edtD,edtC,edtCon;
    TextView txtR1,txtR2;
    Button btnC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edtNV = findViewById(R.id.edtNV);
        edtNP = findViewById(R.id.edtNP);
        edtD = findViewById(R.id.edtD);
        edtC = findViewById(R.id.edtC);
        edtCon = findViewById(R.id.edtCon);
        txtR1 = findViewById(R.id.txtR1);
        txtR2 = findViewById(R.id.txtR2);
        btnC = findViewById(R.id.btnC);
        btnC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double d,c,con,r1,r2;
                try {
                    d = Double.parseDouble(edtD.getText().toString());
                    c = Double.parseDouble(edtC.getText().toString());
                    con = Double.parseDouble(edtCon.getText().toString());
                    r1 = d/con;
                    txtR1.setText("O Combustivel para o destino é: "+r1);
                    r2 = r1*c;
                    txtR2.setText("O custo da viagem é: "+r2);
                }catch (NumberFormatException e){
                    Toast.makeText(MainActivity.this, "Erro", Toast.LENGTH_SHORT).show();
                }
            }
        });
        };
    }
