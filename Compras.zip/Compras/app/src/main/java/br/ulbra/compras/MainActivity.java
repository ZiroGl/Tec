    package br.ulbra.compras;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    CheckBox ckA, ckL, ckC, ckF,ckCC;
    Button btnTotal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ckA = (CheckBox) findViewById(R.id.ckA);
        ckL = (CheckBox) findViewById(R.id.ckL);
        ckC = (CheckBox) findViewById(R.id.ckC);
        ckF = (CheckBox) findViewById(R.id.ckF);
        ckCC = (CheckBox) findViewById(R.id.ckCC);
        Button btnTotal = (Button) findViewById(R.id.btnTotal);
        btnTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double total = 0;
                if (ckA.isChecked()) { total += 2.69; }
                if (ckL.isChecked()) { total += 5.00; }
                if (ckC.isChecked()) { total += 9.7; }
                if (ckF.isChecked()) { total += 2.30; }
                if(ckCC.isChecked()) { total += 2.00;}
                AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
                dialogo.setTitle("Aviso");
                dialogo.setMessage("Valor total da compra"+ String.valueOf(total));
                dialogo.setNeutralButton("OK", null);
                dialogo.show();
            }
        });
        };
    }
